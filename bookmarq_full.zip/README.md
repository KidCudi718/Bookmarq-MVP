# 📚 Bookmarq

Bookmarq turns your X/Twitter bookmarks into actionable tasks and logs them on Hedera HCS.

*Connect → Classify → Approve → Log → (future) Reward*
